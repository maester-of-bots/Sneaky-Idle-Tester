import SwiftUI

@main
struct FjallabærSheepFarmApp: App {
    var body: some Scene {
        WindowGroup {
            AppFlowView()
        }
    }
}

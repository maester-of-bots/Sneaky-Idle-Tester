import SwiftUI

@main
struct IdleClickerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
